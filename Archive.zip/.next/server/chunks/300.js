exports.id = 300;
exports.ids = [300];
exports.modules = {

/***/ 1288:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "Home_header__GCVRv",
	"header-content-top": "Home_header-content-top__yUJ1K",
	"content": "Home_content__Zy02X",
	"fas": "Home_fas__6zgpN",
	"container": "Home_container__bCOhY",
	"logo": "Home_logo__27_tb",
	"open-search": "Home_open-search__l45uH",
	"fa-search": "Home_fa-search__ifu6S",
	"input-open-search": "Home_input-open-search___CLqo",
	"search": "Home_search__M4hYu",
	"input-search": "Home_input-search__yDL04",
	"button-search": "Home_button-search__xnTwU",
	"nav-content": "Home_nav-content__7dp_J",
	"nav-content-list": "Home_nav-content-list__TJWvt",
	"nav-content-item": "Home_nav-content-item__TV6fa",
	"item-arrow": "Home_item-arrow__5qZUB",
	"open-menu-login-account": "Home_open-menu-login-account__qe_QI",
	"input-menu": "Home_input-menu__2fLys",
	"login-list": "Home_login-list__mHkWF",
	"login-list-item": "Home_login-list-item__2F_rU",
	"account-login": "Home_account-login__seg5C",
	"login-text": "Home_login-text__XRhFf",
	"nav-content-link": "Home_nav-content-link__hG754",
	"nav-container": "Home_nav-container__EToUe",
	"nav-row": "Home_nav-row__3FFkL",
	"nav-row-list": "Home_nav-row-list__hohWt",
	"nav-row-list-link": "Home_nav-row-list-link__HpHiV",
	"featured-category": "Home_featured-category__tBkVj",
	"all-navigator": "Home_all-navigator__YxdQu",
	"fa-angle-up": "Home_fa-angle-up__T5GKm",
	"fa-angle-down": "Home_fa-angle-down___a94P",
	"all-category-nav": "Home_all-category-nav__nJHM2",
	"open-menu-all": "Home_open-menu-all__6c1Mr",
	"input-menu-all": "Home_input-menu-all__VenL3",
	"all-category-list": "Home_all-category-list__0mJnN",
	"down-svg": "Home_down-svg__8NzS6",
	"up-svg": "Home_up-svg__Rh_Ox",
	"all-category-list-item": "Home_all-category-list-item__IKzHD",
	"category-second-list": "Home_category-second-list__kWTLa",
	"all-category-list-link": "Home_all-category-list-link__rLIVb",
	"img-product-menu": "Home_img-product-menu__FpVFO",
	"category-second-list-ul": "Home_category-second-list-ul__D0tUM",
	"category-second-item": "Home_category-second-item__UkANh",
	"fa-bars": "Home_fa-bars__Cjt4J"
};


/***/ }),

/***/ 4852:
/***/ ((module) => {

// Exports
module.exports = {
	"body": "home_body_body__FUWoi",
	"cart": "home_body_cart__Jhl21",
	"footer": "home_body_footer__r8Orp",
	"grid": "home_body_grid__s_so1",
	"grid__col": "home_body_grid__col__kN_bH",
	"full": "home_body_full__ApevF",
	"flex": "home_body_flex__ZyCQr",
	"buy__now": "home_body_buy__now__s5sru",
	"add__to__basket": "home_body_add__to__basket__tre0T",
	"rating": "home_body_rating__MOcDa",
	"ft": "home_body_ft__G09FV",
	"color": "home_body_color__9uOSm"
};


/***/ }),

/***/ 3983:
/***/ ((module) => {

// Exports
module.exports = {
	"product__list": "product_list_product__list__cFTsZ"
};


/***/ }),

/***/ 3785:
/***/ ((module) => {

// Exports
module.exports = {
	"product-card": "product_product-card__jl0V8",
	"badge": "product_badge__QPO3C",
	"product-tumb": "product_product-tumb__WAIap",
	"product-details": "product_product-details__c97TY",
	"product-catagory": "product_product-catagory__fW_eR",
	"product-bottom-details": "product_product-bottom-details__vMKCI",
	"product-price": "product_product-price__E68Eu",
	"product-links": "product_product-links__maSXX",
	"heart": "product_heart__HZdPm"
};


/***/ }),

/***/ 1932:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1288);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4563);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3788);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__, _redux_slices_cart__WEBPACK_IMPORTED_MODULE_3__]);
([_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__, _redux_slices_cart__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const CartItems = next_dynamic__WEBPACK_IMPORTED_MODULE_4___default()(null, {
    loadableGenerated: {
        modules: [
            "../components/Header.jsx -> " + "../components/CartItems"
        ]
    },
    ssr: false
});
function Header() {
    const cart_product_count = (0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_3__/* .products */ .RB)()?.length;
    const [show, setShow] = react__WEBPACK_IMPORTED_MODULE_5___default().useState(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default().header),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["header-content-top"]),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default().content),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default().fas),
                                    icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faPhoneSquareAlt
                                }),
                                "(00)0000-0000"
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                    icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faEnvelopeSquare,
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default().fas)
                                }),
                                "officialgurvir2007@gmail.com"
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default().container),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["open-search"]),
                        htmlFor: "open-search",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["input-open-search"]),
                                id: "open-search",
                                type: "checkbox",
                                name: "menu"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default().search),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["button-search"]),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faSearch
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        placeholder: "What are you looking for?",
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["input-search"])
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-content"]),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-content-list"]),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-content-item account-login"]),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["open-menu-login-account"]),
                                        htmlFor: "open-menu-login-account",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["input-menu"]),
                                                id: "open-menu-login-account",
                                                type: "checkbox",
                                                name: "menu"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                                icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faUserCircle
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["login-text"]),
                                                children: "Sign In"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["login-list"]),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["login-list-item"]),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "#",
                                                    children: "My account"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["login-list-item"]),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "#",
                                                    children: "Create account"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["login-list-item"]),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "#",
                                                    children: "logout"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-content-item"]),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-content-link"]),
                                        "data-items-count": "0",
                                        href: "#",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faHeart
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-content-item"]),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-content-link"]),
                                        "data-items-count": cart_product_count,
                                        href: "#",
                                        onClick: ()=>setShow(true),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faShoppingBag
                                        })
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-container"]),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-nav"]),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["open-menu-all"]),
                            htmlFor: "open-menu-all",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["input-menu-all"]),
                                    id: "open-menu-all",
                                    type: "checkbox",
                                    name: "menu-open"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-navigator"]),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faBars
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "All category"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faAngleDown,
                                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["down-svg"])
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faAngleUp,
                                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["up-svg"])
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list"]),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-item"]),
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                    href: "#",
                                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-link"]),
                                                    children: [
                                                        "Smartphones",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                                            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faAngleRight
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["category-second-list"]),
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["category-second-list-ul"]),
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["category-second-item"]),
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                        href: "#",
                                                                        children: "Iphone 10"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["category-second-item"]),
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                        href: "#",
                                                                        children: "Galaxy Note 10"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["category-second-item"]),
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                        href: "#",
                                                                        children: "Motorola One "
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["category-second-item"]),
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                        href: "#",
                                                                        children: "Galaxy A80 "
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["category-second-item"]),
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                        href: "#",
                                                                        children: "Galaxy M "
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["category-second-item"]),
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                        href: "#",
                                                                        children: "Huaway P30 "
                                                                    })
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["img-product-menu"]),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                src: "https://i.ibb.co/Vvndkmy/banner.jpg"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-item"]),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                href: "#",
                                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-link"]),
                                                children: [
                                                    "Furniture",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                                        icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faAngleRight
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-item"]),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                href: "#",
                                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-link"]),
                                                children: [
                                                    "Toys",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                                        icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faAngleRight
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-item"]),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                href: "#",
                                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-link"]),
                                                children: [
                                                    "Computing",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                                        icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faAngleRight
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-item"]),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                href: "#",
                                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-link"]),
                                                children: [
                                                    "Games",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                                        icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faAngleRight
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-item"]),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                href: "",
                                                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["all-category-list-link"]),
                                                children: [
                                                    "Automotive",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
                                                        icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_2__.faAngleRight
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["featured-category"]),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row"]),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list"]),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "#",
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list-link"]),
                                        children: "Smartphones"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list"]),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "#",
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list-link"]),
                                        children: "furniture"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list"]),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "#",
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list-link"]),
                                        children: "Toys"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list"]),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "#",
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list-link"]),
                                        children: "Computing"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list"]),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "#",
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list-link"]),
                                        children: "Games"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list"]),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "#",
                                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_7___default()["nav-row-list-link"]),
                                        children: "Automotive"
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartItems, {
                show: show,
                setShow: setShow
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8366:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ HotDeals)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_home_body_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4852);
/* harmony import */ var _styles_home_body_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_home_body_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Product__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3166);
/* harmony import */ var _ProductList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8540);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Product__WEBPACK_IMPORTED_MODULE_1__]);
_Product__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function HotDeals({ notContainer  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: notContainer ? "" : (_styles_home_body_module_css__WEBPACK_IMPORTED_MODULE_3___default().body),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        children: "HOT DEALS"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {})
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ProductList__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Product__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        hotDeals: true
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Product__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        hotDeals: true
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Product__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        hotDeals: true
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3166:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Product)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_product_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3785);
/* harmony import */ var _styles_product_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_styles_product_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4563);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6555);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3788);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__, uuid__WEBPACK_IMPORTED_MODULE_6__, _redux_slices_cart__WEBPACK_IMPORTED_MODULE_8__]);
([_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__, uuid__WEBPACK_IMPORTED_MODULE_6__, _redux_slices_cart__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function Product({ hotDeals  }) {
    const [oldPrice, setOldPrice] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(250);
    const [newPrice, setNewPrice] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(50);
    const [link, setLink] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("#");
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(function() {
        setNewPrice(Math.round(Math.random() * (100 - 75)) + 75);
        setOldPrice(Math.round(Math.random() * (250 - 150) + 150));
        setLink((0,uuid__WEBPACK_IMPORTED_MODULE_6__.v4)());
    }, []);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
    const addProduct = ()=>dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_8__/* .add_product */ .tJ)({
            id: link
        }));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_product_module_css__WEBPACK_IMPORTED_MODULE_9___default()["product-card"]),
        children: [
            hotDeals && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_product_module_css__WEBPACK_IMPORTED_MODULE_9___default().badge),
                children: "Hot Deal"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_product_module_css__WEBPACK_IMPORTED_MODULE_9___default()["product-tumb"]),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: "https://stimg.cardekho.com/images/carexteriorimages/930x620/Hyundai/Venue/9154/1655441194954/front-left-side-47.jpg?tr=w-375",
                    width: 380,
                    height: 300
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_product_module_css__WEBPACK_IMPORTED_MODULE_9___default()["product-details"]),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_styles_product_module_css__WEBPACK_IMPORTED_MODULE_9___default()["product-catagory"]),
                        children: "Category"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                            href: "/product/" + link,
                            children: "Product Title"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Lorem ipsum dolor sit   amet, consectetur adipisicing elit. Vero, possimus nostrum!"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_product_module_css__WEBPACK_IMPORTED_MODULE_9___default()["product-bottom-details"]),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_product_module_css__WEBPACK_IMPORTED_MODULE_9___default()["product-price"]),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                                        children: [
                                            "$",
                                            oldPrice
                                        ]
                                    }),
                                    "$",
                                    newPrice
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_product_module_css__WEBPACK_IMPORTED_MODULE_9___default()["product-links"]),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "#",
                                        onClick: (e)=>e.preventDefault(),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__.FontAwesomeIcon, {
                                            className: (_styles_product_module_css__WEBPACK_IMPORTED_MODULE_9___default().heart),
                                            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faHeart
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "#",
                                        onClick: (e)=>e.preventDefault(),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__.FontAwesomeIcon, {
                                            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faShoppingBag,
                                            onClick: addProduct
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8540:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProductList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_product_list_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3983);
/* harmony import */ var _styles_product_list_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_product_list_module_css__WEBPACK_IMPORTED_MODULE_1__);


function ProductList({ children  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_product_list_module_css__WEBPACK_IMPORTED_MODULE_1___default().product__list),
        children: children
    });
}


/***/ }),

/***/ 3788:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RB": () => (/* binding */ products),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "tJ": () => (/* binding */ add_product)
/* harmony export */ });
/* unused harmony export cartSlice */
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6555);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_0__]);
uuid__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "cart",
    initialState: {
        products: [
            {}
        ]
    },
    reducers: {
        add_product: (state, payload)=>{
            const product = state.products.find((a)=>a.id == payload.payload.id);
            !product ? state.products.push(payload.payload) : null;
        }
    }
});
const products = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.cart.products);
const { add_product  } = cartSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;